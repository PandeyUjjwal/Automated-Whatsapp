# -*- coding: utf-8 -*-
"""
Created on Wed May 15 17:42:40 2019

@author: 3191671ran
"""
from tkinter import *
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
import pandas as pd
import re

def quit():
    win.destroy()

def send():
    string = fname.get()
    driver = webdriver.Chrome(r'chromedriver.exe')
    driver.get("https://web.whatsapp.com/")
    wait = WebDriverWait(driver, 600)



    xls = pd.ExcelFile(r"contact.xlsx")
    df1 = xls.parse('Sheet1')
    dfToList = df1['Name'].tolist()
#print(dfToList)
    names=dfToList
    print(names)
    i = 0
    while i < len(names):
        target = ('"' + names[i] + '"')
        Name = (target[6:len(target) - 1])  
#        string = "Good Evening!" + Name + " ji                                                                                             Hope you are doing well.                                                                                                                                                                              We have opening for an accountant role at sector 48 Gurugram. Client is into interior designing business and has budget near about 18-21K per month and Saturday will be working. In case interested, please reply yes and share your CV. We are a CA firm based out in same building who monitor your quality closely & provide you technical assistance.                                                                                                Regards,                                                                                                                       Patron Accounting LLP"
#   print(string)

        x_arg = '//button[.//span[@data-icon="search"]]/..//input'
        new_chat = wait.until(EC.presence_of_element_located((By.XPATH, x_arg)))
        new_chat.send_keys(target[1:len(target) - 1])

        time.sleep(5)
    
        x_arg = '//span[contains(@title,' + target + ')]'
        group_title = wait.until(EC.presence_of_element_located((By.XPATH, x_arg)))
        print(group_title)
        print("after wait")
        group_title.click()
        
        
        inp = "//div[@contenteditable='true']"
        inp_xpath = '//div[@class="input"][@dir="auto"][@data-tab="1"]'
        input_box = wait.until(EC.presence_of_element_located((By.XPATH, inp))) 
        input_box.send_keys(string + Keys.ENTER)
        time.sleep(5)
        i += 1


def show_data():
    print(fname.get())


win = Tk()
# try fiddling with these root.geometry values
win.title('WhatsApp')
win.configure(background='#324468')
              
win.minsize(width=50, height=50)
win.geometry('400x300+0+0')

Label( win, text='Message',bg='#c14e21', fg='#ffffff').grid(row=2,pady=40)
#Label( win, text='Last Name' ).grid( row=1 )

fname = Entry(win)
#lname = Entry( win )
#fname.get()
#print(fname.get())

fname.grid(row=2, column=5,pady=40 )
#lname.grid( row=1, column=1 )
fname.place(x=100, y=30, height=100, width=200)


#Button( win, text='Exit', command=win.quit ).grid( row=3, column=0, sticky=W, pady=4 )
Button1 = Button(win, text='Send', command=send, bg='#c14e21', fg='#ffffff')

#Button1 = Button(win, text='Send', command=show_data, bg='#c14e21', fg='#ffffff')
Button2 = Button(win, text='Close', command=quit, bg='#c14e21', fg='#ffffff')

Button1.place(x=100, y=180, height=30, width=50)
Button2.place(x=200, y=180, height=30, width=50)


mainloop()






