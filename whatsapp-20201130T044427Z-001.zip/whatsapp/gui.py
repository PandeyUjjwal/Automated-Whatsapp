
from tkinter import * 
def runfile():
    print("Openning the excel file.")
    open(r"C:\Users\verdhman\Desktop\whatsapp/Names_cus10.xlsx")

def popupmsg():
    popup = Tk()
    popup.wm_title("All about the youmessenger")
    popup.config(menu=menu,background='#87ceeb') 
    Label(popup, text='''     Instructions to use the Youmessenger \n
                        1. Define the batch size(lot size that will receive the message) \n
        2. Define the delay time in seconds \n
                        3. Select the checkbox of text and image accordingly \n
                        4. Hit the send button to send message \n
                        ** The batch size and delay can not be empty \n
                        ** It is necessary to select either text of image''',bg='#87ceeb').grid(row=0,column=11,pady=10) 

    
    
    popup.mainloop()

def send():
    text_flag=var1.get() #bool for text
    image_flag=var2.get() #bool for image
    try:
        batch_size=int(e1.get())  #batch size
        timer=int(e2.get()) #timer
    except:
        print("Batch Size and Timetr are integer numbers")
        exit()
            
    if not (batch_size > 0 and timer > 0):
        print("Invalid Batch Size or Timer")
        exit()
    elif not (text_flag or image_flag):
        print("Atleast one flag is required")
        exit()

    if text_flag:
        try :
            print("sending text messages")
            import send_text_message
            send_text_message.main(batch_size, timer)
            print("finished sending text messages")
        except ImportError:
            print("Text Engine Not Found !")
        except Exception as error:
            print("Error: ", error)


    if image_flag:
        try :
            print("sending image messages")
            import send_image_message
            send_image_message.main(batch_size, timer)
            print("fininshed sending image messages")
        except ImportError:
            print("Image Engine Not Found !")
        except Exception as error:
            print("Error: ", error)

master = Tk() 
menu = Menu(master) 

master.config(menu=menu,background='#87ceeb') 
filemenu = Menu(menu) 
menu.add_cascade(label='File', menu=filemenu) 
#filemenu.add_command(label='New') 
filemenu.add_command(label='Open...',command=runfile) 
filemenu.add_separator() 
filemenu.add_command(label='Exit', command=master.quit) 
helpmenu = Menu(menu) 
menu.add_cascade(label='Help', menu=helpmenu) 
helpmenu.add_command(label='About',command=popupmsg) 




master.title('Youmessenger')
var1 = IntVar() 
Checkbutton(master, text='Text', variable=var1).grid(row=10,column=2, sticky=W,padx=10,pady=13) 
var2 = IntVar() 
Checkbutton(master, text='Image', variable=var2).grid(row=10,column=11, sticky=W,padx=10,pady=13) 
Label(master, text='batch size').grid(row=0,column=2,pady=10) 
Label(master, text='delay time').grid(row=0,column=11,pady=10) 
e1 = Entry(master) 
e2 = Entry(master) 
e1.grid(row=5, column=2,pady=7) 
e2.grid(row=5, column=11,pady=7)
w=Button(master,text='SEND',width=25,activebackground='black',activeforeground='white',command=send,pady=5).grid(row=15,column=10)

mainloop()  




