# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""    
###------------------------------------------------------###    
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
import xlrd
import pandas as pd
import re
import os
import schedule


browser = webdriver.Chrome(r'C:\Users\verdhman\Desktop\project\Whatsapp Automation\whatsapp/chromedriver/chromedriver.exe')
browser.get("https://web.whatsapp.com/")
wait = WebDriverWait(browser, 600)


def send(name, image_name):
    
    target = ('"' + name + '"')
    target_image = image_name

    x_arg = '//button[.//span[@data-icon="search"]]/..//input'
    new_chat = wait.until(EC.presence_of_element_located((By.XPATH, x_arg)))
    new_chat.send_keys(target[1:len(target) - 1])
        
    x_arg = '//span[contains(@title,' + target + ')]'
    group_title = wait.until(EC.presence_of_element_located((By.XPATH, x_arg)))
    print(group_title)
    print("after wait")
    time.sleep(5)
    group_title.click()
        
    # Attachment Drop Down Menu
    clipButton = browser.find_element_by_xpath('//*[@id="main"]/header/div[3]/div/div[2]/div/span')
    clipButton.click()
    time.sleep(5)
    # To send Videos and Images.
    mediaButton = browser.find_element_by_xpath('//*[@id="main"]/header/div[3]/div/div[2]/span/div/div/ul/li[1]/button')
    mediaButton.click()
   #  element = browser.find_element_by_xpath('//*[@id="main"]/header/div[3]/div/div[2]/span/div/div/ul/li[1]/button')
    time.sleep(5)
    
    os.system(r"Ca1.exe")
    time.sleep(5)
    
    whatsapp_send_button = browser.find_element_by_xpath('//*[@id="app"]/div/div/div[2]/div[2]/span/div/span/div/div/div[2]/span[2]/div/div/span')
    whatsapp_send_button.click()
    time.sleep(5)
              
def main(batch_size, timer):

   xls = pd.ExcelFile(r"./Names_cus10.xlsx")
   df1 = xls.parse('Sheet1')
   dfToList = df1['Name'].tolist()
   dfToImageList = df1['ImageName'].tolist()
   names=dfToList
   images=dfToImageList

   print(names)

   i = 0
   counter = 0
   for i,y in enumerate(names):        
      if i ==229:
         time.sleep(timer)   
      elif i == 300:
         time.sleep(timer) 
      elif i == 850:
         time.sleep(timer) 
      elif i == 1050:
         time.sleep(timer) 
      elif i == 750:
         time.sleep(timer) 
      elif i == 900:
         time.sleep(timer)     
      elif i == 1050:
         time.sleep(timer)  
            
      name = names[i]
      image_name = images[i]
   #        print(name)
         
      target = ('"' + names[i] + '"')
      print(target)
      
      x_arg = '//button[.//span[@data-icon="search"]]/..//input'
      new_chat = wait.until(EC.presence_of_element_located((By.XPATH, x_arg)))
      time.sleep(5)
      print("CHAT: ", new_chat)
      new_chat.send_keys(target[1:len(target) - 1])
      x_arg = '//span[contains(@title,' + target + ')]'
      time.sleep(6)    
      y = browser.find_elements_by_xpath('//div[@class="_3dwyT"]/span')
      print(y)
   #        send()
         
      if y ==[]:           
         print("sending")
   #      browser.find_element_by_class_name("C28xL").click()
         browser.find_element_by_class_name("_1XCAr").click()
         
         if counter >= int(batch_size):
            time.sleep(timer)
         else:
            counter += 1

         send(name, image_name)          
      elif i == len(names): 
         print("beaking")
         break
      else:
         print("continue")
         browser.find_element_by_class_name("_1XCAr").click()     
   #      browser.find_element_by_class_name("C28xL").click()
         continue          

# if __name__ == "__main__":
    
#     batch_size = 50 #sys.argv[1]
#     timer = 86400 #sys.argv[2]
#     main(batch_size, timer)