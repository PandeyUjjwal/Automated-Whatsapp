# Whatsapp Automation

## Setting up the environment

1. Install Python-3.7.3
2. Install Virtual Environment ```pip install --upgrade virtualenv```

## Instruction of Use

Step 1: Create a virtual environment

run following command in bash
```$ virtualenv venv```

Step 2: Activate the environment

a) Windows
```$ source venv/Scripts/activate```

a) Ubuntu
```$ source venv/bin/activate```

Step 3: Install Dependencies

run following command
```$ pip install -r requirements.txt```

Step 4: Execute GUI

```$ py gui.py```
or
```$ python gui.py```
or
```$ python3 gui.py```