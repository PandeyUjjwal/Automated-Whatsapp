# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""    
###------------------------------------------------------###    
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
import xlrd
import pandas as pd
import re
import os
import schedule


browser = webdriver.Chrome(r'C:\Users\verdhman\Desktop\whatsapp/chromedriver.exe')
# browser = webdriver.Firefox(executable_path = r'E:\Python\whatsapp\firefox\geckodriver.exe')
browser.get("https://web.whatsapp.com/")
wait = WebDriverWait(browser, 600)

def send(name, message):
    
    target = ('"' + name + '"')
    
   # To send Text.
    #zomato   - "Greetings from Patron Accounting LLP!                                                                                                       File your income-tax and  GST returns accurately and on-time under the supervision of expert CAs. Please let us know our Pune office will get in touch with you.                                                                                                                                                           Patron Accounting LLP                                                                              Partner you can rely on                                                                                                                  www.patronaccounting.com                                                                                                                         info@patronaccounting.com                                                                                                             099200-75893"
    #Coworking   - "Greetings from Patron Accounting LLP!                                                                                                       We have strong team present in different parts of India which offer services related to Income Tax, GST, ROC etc. We can work together to give better experience to your clients. If interested, please let us know our Pune office will contact you.                                                                                                                                                           Patron Accounting LLP                                                                              Partner you can rely on                                                                                                                  www.patronaccounting.com                                                                                                                         info@patronaccounting.com                                                                                                             099200-75893"
    #calendar -  "Greetings from Patron Accounting LLP!                                                                                                          Mark the important dates for the month of June.                                                                                                                                                           Patron Accounting LLP                                                                              Partner you can rely on                                                                                                                  www.patronaccounting.com                                                                                                                         info@patronaccounting.com                                                                                                             "
#    string = "Dear Fellow Professional                                                                                                      Hope you are doing well.                                                                                                                                                           We are Chartered Accountant firm based out in Pune and have other office in Delhi-NCR. We work primarily in field of accounting, tax audit, statutory audits and other related activities.                                                                              Looking forward to get associated with you for any assignment based out in Pune or Delhi-NCR.                                                                                                                    Have a nice day!                                                                                             Regards,                                                                                                                         CA Sundram Gupta                                                                                                             099200-75893"
    
    # Message Goes Here, in string variable

    string = message                                                                                                                                    

    
    x_arg = '//button[.//span[@data-icon="search"]]/..//input'
    new_chat = wait.until(EC.presence_of_element_located((By.XPATH, x_arg)))
    new_chat.send_keys(target[1:len(target) - 1])
    time.sleep(5)
    
    x_arg = '//span[contains(@title,' + target + ')]'
    group_title = wait.until(EC.presence_of_element_located((By.XPATH, x_arg)))
    print(group_title)
    print("after wait")
    group_title.click()
        
        
    inp = "//div[@contenteditable='true']"
    inp_xpath = '//div[@class="input"][@dir="auto"][@data-tab="1"]'
    input_box = wait.until(EC.presence_of_element_located((By.XPATH, inp))) 
    input_box.send_keys(string + Keys.ENTER)
    time.sleep(5)
              
def main(batch_size, timer):

   xls = pd.ExcelFile(r"C:\Users\verdhman\Desktop\whatsapp/Names_cus10.xlsx")
   df1 = xls.parse('Sheet1')
   dfToList = df1['Name'].tolist()
   # get message list from xlsx file
   dfMessageList = df1['message'].tolist()
   names=dfToList
   messages=dfMessageList

   print(names)

   i = 0
   counter = 0
   for i,y in enumerate(names):        
      if i == 200:
         time.sleep(timer)   
      elif i == 300:
         time.sleep(timer) 
      elif i == 450:
         time.sleep(timer) 
      elif i == 600:
         time.sleep(timer) 
      elif i == 750:
         time.sleep(timer) 
      elif i == 900:
         time.sleep(timer)     
      elif i == 1050:
         time.sleep(timer)  
            
      name = names[i]
      message = messages[i]
   #        print(name)
         
      target = ('"' + names[i] + '"')
      print(target)
      
      x_arg = '//button[.//span[@data-icon="search"]]/..//input'
      new_chat = wait.until(EC.presence_of_element_located((By.XPATH, x_arg)))
      new_chat.send_keys(target[1:len(target) - 1])
      x_arg = '//span[contains(@title,' + target + ')]'
      time.sleep(10)    
      y = browser.find_elements_by_xpath('//div[@class="_3dwyT"]/span')
      print(y)
   #        send()
         
      if y ==[]:           
   #      browser.find_element_by_class_name("C28xL").click()
         browser.find_element_by_class_name("_1XCAr").click()

         if counter >= int(batch_size):
            time.sleep(timer)
         else:
            counter += 1

         send(name, message)          
      elif i == len(names): 
         break
      else:
         browser.find_element_by_class_name("_1XCAr").click()     
   #      browser.find_element_by_class_name("C28xL").click()
         continue          

# if __name__ == "__main__":
    
#     batch_size = 50 #sys.argv[1]
#     timer = 86400 #sys.argv[2]
#     main(batch_size, timer)